// script.js
document.getElementById('lead-form').addEventListener('submit', function (e) {
  e.preventDefault();
  const nome = this.nome.value.trim();
  const email = this.email.value.trim();
  const mensagem = this.mensagem.value.trim();
  if (!nome || !email) {
    alert('Por favor, preencha nome e e-mail.');
    return;
  }
  const assunto = encodeURIComponent("Lead via landing page NDX");
  const corpo = encodeURIComponent(`Nome: ${nome}\nEmail: ${email}\nMensagem: ${mensagem}`);
  window.location.href = `mailto:seuemail@dominio.com?subject=${assunto}&body=${corpo}`;
});
